# Read about factories at https://github.com/thoughtbot/factory_girl

FactoryGirl.define do
  factory :payment_order do
    date '2015-03-04 20:25:46'
  end
end
