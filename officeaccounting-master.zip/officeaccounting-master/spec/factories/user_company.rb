FactoryGirl.define do
  factory :user_company
end
