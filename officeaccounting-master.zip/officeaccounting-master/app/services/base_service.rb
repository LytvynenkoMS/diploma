class BaseService
  def initialize(session)
    @session = session
  end
end
