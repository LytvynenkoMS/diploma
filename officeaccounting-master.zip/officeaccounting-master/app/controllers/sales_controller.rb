class SalesController < ApplicationController
end
