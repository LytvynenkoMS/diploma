class ToolEquipmentsController < ApplicationController
  before_action :redirect_to_new_session
end
