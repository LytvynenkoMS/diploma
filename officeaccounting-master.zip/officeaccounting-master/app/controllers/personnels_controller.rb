class PersonnelsController < ApplicationController
  before_action :redirect_to_new_session

  def index; end
end
