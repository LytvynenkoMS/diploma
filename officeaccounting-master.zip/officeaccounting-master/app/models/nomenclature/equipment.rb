class Nomenclature::Equipment < Nomenclature; end
