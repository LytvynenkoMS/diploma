class Nomenclature::Material < Nomenclature; end
