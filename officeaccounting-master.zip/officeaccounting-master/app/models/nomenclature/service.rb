class Nomenclature::Service < Nomenclature; end
