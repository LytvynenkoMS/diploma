class Nomenclature::Product < Nomenclature; end
