class Nomenclature::Production < Nomenclature; end
