class Participant < ActiveRecord::Base
  belongs_to :chat
end
