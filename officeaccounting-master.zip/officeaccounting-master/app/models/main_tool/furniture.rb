class MainTool::Furniture < MainTool; end
