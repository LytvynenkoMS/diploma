class MainTool::Building < MainTool; end
