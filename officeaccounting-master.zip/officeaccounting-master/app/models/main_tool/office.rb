class MainTool::Office < MainTool; end
