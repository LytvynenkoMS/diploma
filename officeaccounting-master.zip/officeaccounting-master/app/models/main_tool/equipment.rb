class MainTool::Equipment < MainTool; end
