class MainTool::Vehicle < MainTool; end
