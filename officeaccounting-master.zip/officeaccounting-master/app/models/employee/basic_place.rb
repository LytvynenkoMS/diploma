class Employee::BasicPlace < Employee; end
