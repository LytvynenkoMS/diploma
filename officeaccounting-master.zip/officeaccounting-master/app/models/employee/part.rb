class Employee::Part < Employee; end
