class TaxInspection < ActiveRecord::Base
end
