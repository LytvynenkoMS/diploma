class CurrencyTransaction::Sale < CurrencyTransaction; end
