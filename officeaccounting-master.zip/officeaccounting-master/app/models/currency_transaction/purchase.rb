class CurrencyTransaction::Purchase < CurrencyTransaction; end
