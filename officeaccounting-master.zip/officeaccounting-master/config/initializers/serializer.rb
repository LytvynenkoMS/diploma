ActiveModel::Serializer.root = false
