module StateMachine
  module Integrations
    module ActiveModel
      public :around_validation
    end
  end
end
