Kaminari.configure do |config|
  config.default_per_page = 10
end
